# Thingspeak_CPU_Python-Code
Python code for uploading CPU Data to your Thingspeak Server
